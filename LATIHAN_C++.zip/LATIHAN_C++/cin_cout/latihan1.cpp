#include <iostream>
using namespace std;

int main(){
    cout << "Haloww" << endl;
    return 0;
}