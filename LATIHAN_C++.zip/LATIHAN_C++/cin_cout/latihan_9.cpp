#include<iostream>
using namespace std;

int main(){
    int sisi;
    int luas;

    cout << "Masukkan sisi :" << endl;
    cin >> sisi;

    luas = sisi * sisi;

    cout << "Masukkan sisi : " << sisi << endl;
    cout << "luas : " << luas << endl;

    return 0;


}