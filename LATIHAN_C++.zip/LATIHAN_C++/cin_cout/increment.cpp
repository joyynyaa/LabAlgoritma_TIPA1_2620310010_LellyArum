#include <iostream>
using namespace std;

int main() {
    // inisialisasi variabel
    int x = 50;
    int a, b, c, d, e;

    // proses
    a = x > 5 + 5;  // 1
    b = x > 100;    // 2
    c = a && b;     // 3
    d = a || b;     // 4
    e = !(c);       // 5

    // output
    cout << "Nilai a = x > 5 + 5 = " << a << endl;
    cout << "Nilai b = x > 100 = " << b << endl;
    cout << "Nilai c = a && b = " << c << endl;
    cout << "Nilai d = a || b = " << d << endl;
    cout << "Nilai e = !(c) = " << e << endl;

    getchar();
}

