#include<iostream>
using namespace std;

int main(){
    float nilai_tugas;
    float nilai_uts;
    float nilai_uas;
    float nilai_akhir;

    cout << "nilai_tugas: " << endl;
    cin >> nilai_tugas;

    cout << "nilai_uts: ";
    cin >> nilai_uts;

    cout << "nilai_uas: ";
    cin >> nilai_uas;

    nilai_akhir = (nilai_tugas * 0.3) + (nilai_uts * 0.3) + (nilai_uas * 0.4);

    cout << endl << "Output" << endl;
    cout << "nilai_tugas: " << nilai_tugas << endl;
    cout << "nilai_uts: " << nilai_uts << endl;
    cout << "nilai_uas: " << nilai_uas << endl;
    cout << "nilai_akhir: " << nilai_akhir << endl;
    
    return 0;


}