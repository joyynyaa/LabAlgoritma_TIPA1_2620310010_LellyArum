#include<iostream>
using namespace std;

int main(){
float celcius;
float farenheit;
float kelvin;

cout << "Masukkan suhu (celcius): " << endl;
cin >> celcius;

farenheit = (celcius * 9.0 / 5.0) + 32;
kelvin     = celcius + 273.15;

cout << endl << "Output" << endl;
cout << "Masukkan suhu (celcius): " << celcius << endl;
cout << "farenheit: " << farenheit << endl;
cout << "kelvin: " << kelvin << endl;

return 0;
}