#include<iostream>
using namespace std;

int main(){
    int panjang;
    int lebar;
    int keliling;

    cout << "Masukkan panjang : " << endl;
    cin >> panjang;

    cout << "Masukkan lebar : " << endl;
    cin >> lebar;

    keliling = 2 * (panjang + lebar);

    cout << " panjang : " << panjang << endl;
    cout << " lebar : " << lebar << endl;
    cout << "keliling : " << keliling << endl;

    return 0;

}