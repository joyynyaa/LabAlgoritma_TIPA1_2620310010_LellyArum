#include<iostream>
using namespace std;

int main (){
    int panjang;
    int lebar;
    int luas;

    cout << "Masukkan panjang :" << endl;
    cin >> panjang;

    cout << "Masukkan lebar :" << endl;
    cin >> lebar;

    luas = panjang * lebar;


    cout << endl << "Output" << endl;
    cout << "Masukkan panjang:" << panjang << endl;
    cout << "Masukkan lebar:" << lebar << endl;
    cout << "Luas : " << luas << endl;
    return 0;
 }