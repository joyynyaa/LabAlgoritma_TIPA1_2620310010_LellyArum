#include<iostream>
using namespace std;

int main(){
    float alas;
    float tinggi;
    float luas;

    cout << "Masukkan alas segitiga:" << endl;
    cin >> alas;

    cout << "Masukkan tinggi segitiga:" << endl;
    cin >> tinggi;

    luas = 0.5 * alas * tinggi;

    cout << "Masukkan alas segitiga: " << alas << endl;
    cout << "Masukkan tinggi segitiga: " <<tinggi << endl;
    cout << "Luas segitiga: " << luas << endl;

    return 0;


}