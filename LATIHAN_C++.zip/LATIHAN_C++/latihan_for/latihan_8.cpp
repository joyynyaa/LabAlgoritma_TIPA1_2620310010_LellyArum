#include<iostream>
using namespace std;

int main(){
    int i;
    int y = 0;

    for (i = 1; i<=5; i++){
        cout << i << " ";
        y = y + i;
    }
    cout << endl << " Nilai y = " << y;
}