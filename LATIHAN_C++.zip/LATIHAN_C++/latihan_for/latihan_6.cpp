#include<iostream>
using namespace std;

int main(){
    for(int i = 1; i<=5; i++){
        cout << i << "  kuadrat = " << i * i << endl;
    }
}