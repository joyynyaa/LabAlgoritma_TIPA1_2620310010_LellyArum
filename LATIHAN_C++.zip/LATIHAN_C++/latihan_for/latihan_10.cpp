#include<iostream>
using namespace std;
int main(){
int i;
int x = 0;
int y =0;

for (i = 1; i<=6; i++ ){
    if (i % 2 ==0){
        cout << "Genap";
        x = x + i;
    } else {
        cout << "Ganjil";
        y = y + i;
    }
}
 cout << endl << "Total Genap (x) = " << x << endl;
    cout << "Total Ganjil (y) = " << y << endl;
}