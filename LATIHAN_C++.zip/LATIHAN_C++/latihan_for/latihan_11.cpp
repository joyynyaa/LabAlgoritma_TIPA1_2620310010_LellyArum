#include<iostream>
using namespace std;

int main(){
    int i;

    for ( i =1; i<=20; i++){
        if (i % 4 == 0 && i % 5 == 0){
            cout << i << " ";
        }
    }
}