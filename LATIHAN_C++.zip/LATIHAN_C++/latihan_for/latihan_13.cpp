#include<iostream>
using namespace std;

int main(){
    int i;
    int a = 0;
    int b = 1;
    int c;

    for (i = 1; i <=7; i++){
        cout << a << " ";

        c = a +b;
        a = b;
        b = c;
    }


}