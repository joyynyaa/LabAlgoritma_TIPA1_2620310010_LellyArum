#include<iostream>
using namespace std;

int main(){
    int i;

    for (i = 1; i <=8; i++){
        if (i ==3 ){
            cout << "[TIGA]";
        } else if (i % 2 == 0){
            cout << "Genap";
        } else {
            cout << "Ganjil";
        }
    }
}