
#include<iostream>
using namespace std;

int main(){
    int i;
    int x=0;

    for(i=1; i<=10; i++){
        cout << i << " ";
        x = x + i;
    }
    cout << endl << "Nilai x = " << x;
}