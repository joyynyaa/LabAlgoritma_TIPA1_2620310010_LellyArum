#include<iostream>
using namespace std;

int main(){
    int x = 9;
    for(int i = 1; i <=5; i++){
        cout << x << endl;
    }
}