#include<iostream>
using namespace std;

int main(){
    int i;
    int x;
    x = 2;

    for(i=1; i<=10; i++){
        cout << x*i << " ";
    }
}