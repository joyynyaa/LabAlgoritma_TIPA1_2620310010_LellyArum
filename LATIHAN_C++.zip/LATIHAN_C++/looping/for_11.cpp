#include<iostream>
using namespace std;

int main(){
    int i;
    int x =0;
    int y =0;

    for (i=1; i<=10; i++){
        if (i%2==0) {
            cout << i << " ";
            x = x+i;
        }
        else {
            y += i;
        }
    }

    cout << endl;
    cout << "Nilai x = " << x << endl;
    cout << "Nilai y = " << y;
}