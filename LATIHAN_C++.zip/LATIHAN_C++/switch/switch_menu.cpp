#include<iostream>
using namespace std;

int main(){
    int angka;

    cout << "Masukkan angka : " << endl;
    cin >> angka;

    switch (angka){
    case 1:
    cout << "Satu" << endl;
    break;

    case 2:
    cout << "Dua" << endl;
    break;

    case 3:
    cout << "Tiga" << endl;
    break;

    default:
    cout << "Tidak valid" << endl;
    break;
    }
}
