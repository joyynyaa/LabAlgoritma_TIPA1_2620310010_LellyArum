#include<iostream>
using namespace std;
int main(){
    int nilai;

    cout << "Masukkan nilai : " << endl;
    cin >> nilai;

    if (nilai >= 75){
        cout << "Lulus" << endl;
    }

    else if (nilai >= 60){
        cout << "Remedial" << endl;
    }

    else {
        cout << "Tidak lulus" << endl;
    }
}