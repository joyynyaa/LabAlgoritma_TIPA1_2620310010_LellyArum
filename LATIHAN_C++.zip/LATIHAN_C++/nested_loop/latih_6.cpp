#include<iostream>
using namespace std;

int main(){
    int i;
    int j;
        for (i=1; i<=3; i++){
            for(j=1; j<=2; j++)
            {
                cout << j << " ";
            }
            cout << endl;
        }

    }