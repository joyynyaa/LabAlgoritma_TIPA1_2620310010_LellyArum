#include <iostream>
using namespace std;

int main() {
    int i, j, cek;
    cek = 0;

    for (i = 1; i <= 30; i++) {
        for (j = 1; j <= i; j++) {
            
            if (i % j == 0) {
                cek++;
            }
            
        }
        
        if (cek < 3) { // Cek<3 artinya cuma punya 2 faktor (1 dan dirinya sendiri)
            cout << i << " ";
        }
        
        cek = 0; // Reset hitungan untuk angka berikutnya
    }

    return 0;
}