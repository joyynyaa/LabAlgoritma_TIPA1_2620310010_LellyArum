#include<iostream>
using namespace std;

int main(){
    int i;
    int j;

    for(i=1; i<=2; i++){
        for(j=1; j<=3; j++)
        {
            cout << j;
        }
    cout << endl;
    }
}