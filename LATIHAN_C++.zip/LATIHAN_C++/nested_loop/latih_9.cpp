#include<iostream>
using namespace std;
int main(){
    int n;
    int x;
    int t;
    int i;
    int j;

    x = 1; t = 0; n = 4;
    for(i=1; i<6; i+=2){
        for(j=1; j<10; j+=3)
        {
            t = t + n;
            n = n + x;
            x = x+2;
            cout <<     t   ;
        }
        cout << endl;
    }
}