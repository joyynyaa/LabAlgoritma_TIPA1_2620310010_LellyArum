#include<iostream>
using namespace std;
int main(){
    int i;
    int j;

    for(i=1; i<=4; i++){
        for(j=i; j<=4; j++)
        {cout << j << " ";}
        cout << endl;
    }
}