#include <iostream>
using namespace std;

int main() {
    int I, J;

    for (I = 1; I <= 3; I++) {
        for (J = 1; J <= 4; J++) {
            
            if (I % 2 == 0) {
                cout << I << " ";
            } 
            else {
                cout << J << " ";
            }
            
        }
        cout << endl; 
    }

    return 0;
}