#include<iostream>
using namespace std;
int main(){
  int angka;
    cout << "Masukkan tinggi : ";
    cin >> angka;

    for(int i = 1; i <= angka; i++){
        // Rahasianya: j <= i (bukan j <= angka)
        for(int j = 1; j <= i; j++){ 
            cout << "* ";
        }
        cout << endl;
    }
    return 0;
}   
