#include<iostream>
using namespace std;
int main(){ 
    int total = 0;

    for(int i = 1; i<=9; i+=2){
    cout << i << " ";
    total +=i;
}
cout << total << endl;
}