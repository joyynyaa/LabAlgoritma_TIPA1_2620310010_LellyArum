#include<iostream>
using namespace std;
int main(){
    
    for(int i=4; i<=20; i+=4){
        cout << i << " ";}
        return 0;
}