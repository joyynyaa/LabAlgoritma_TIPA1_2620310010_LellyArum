#include<iostream>
using namespace std;
int main(){
    int belanja;
    float diskon, total;

    cout << "Masukkan total belanja : " << endl;
    cin >> belanja;

    if(belanja > 100000){
        diskon = belanja * 0.10;
        total = belanja - diskon;
        
        cout << "Diskon : " << diskon << endl;
        cout << "Total belanja : " << total << endl;
    } else {
        cout << "Tidak mendapat diskon : " << endl;
        cout << "Total Bayar : " << belanja << endl; 
    }
    return 0;
}