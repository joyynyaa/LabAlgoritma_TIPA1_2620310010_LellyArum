#include<iostream>
using namespace std;
int main(){
    int awal;

    cout << "Masukkan angka start : ";
    cin >> awal;

    while(awal >=1){
        cout << awal << " ";
        awal --;
    }
    cout << "GO!";
return 0;
}