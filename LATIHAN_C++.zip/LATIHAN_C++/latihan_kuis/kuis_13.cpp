#include<iostream>
using namespace std;
int main(){
    int n;
    int total =1;

    cout << "Masukkan angka : ";
    cin >> n;

    for(int i =n; i>=1; i--){
        total = total * i;
    }
    cout << "Hasil faktorial : " << total << endl;
    return 0;
}