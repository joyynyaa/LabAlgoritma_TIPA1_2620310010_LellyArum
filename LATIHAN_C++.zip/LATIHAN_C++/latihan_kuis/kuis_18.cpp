#include<iostream>
using namespace std;
int main(){
    int angka;
    cout << "Masukkan tinggi : ";
    cin >> angka;

    for(int i = 1; i <= angka; i++){
        
        // 1. Cetak Spasi dulu (makin ke bawah makin sedikit spasinya)
        for(int s = 1; s <= angka - i; s++){
            cout << " ";
        }
        
        // 2. Cetak Bintang (rumusnya 2 * i - 1, biar ganjil: 1, 3, 5, 7)
        for(int b = 1; b <= (2 * i - 1); b++){
            cout << "*";
        }
        
        cout << endl;
    }
    return 0;
}