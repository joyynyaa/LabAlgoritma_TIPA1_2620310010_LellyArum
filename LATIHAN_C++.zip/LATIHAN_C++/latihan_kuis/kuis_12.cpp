#include<iostream>
using namespace std;
int main(){
    int angka;
    int jumlah_faktor = 0;

    cout << "Masukkan angka : " << endl;
    cin >> angka;

    for(int i = 1; i <=angka; i++){
        if (angka % i == 0){
            jumlah_faktor++;
        }
    }

    if (jumlah_faktor == 2){
        cout << angka << "  adalah bilangan prima";
    } else {
        cout << angka << "  bukan bilangan prima";
    }
    return 0;
}