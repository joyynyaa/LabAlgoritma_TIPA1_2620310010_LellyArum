#include<iostream>
using namespace std;
int main(){
    int a = 15;
    int b = 4;

    if (a % b == 3){
        cout << "Sisa baginya tiga";
    } else {
        cout << "Sisa baginya bukan tiga";
    }
    return 0;
}