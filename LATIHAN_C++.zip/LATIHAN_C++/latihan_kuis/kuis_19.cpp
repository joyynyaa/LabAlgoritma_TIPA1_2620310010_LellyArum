#include<iostream>
using namespace std;
int main(){
    int ukuran;
    cout << "Masukkan ukuran : ";
    cin >> ukuran;

    for(int i = 1; i <= ukuran; i++){
        for(int j = 1; j <= ukuran; j++){
            // Jika i+j habis dibagi 2 (genap)
            if ((i + j) % 2 == 0) {
                cout << "1 ";
            } else {
                cout << "0 ";
            }
        }
        cout << endl;
    }
    return 0;
}