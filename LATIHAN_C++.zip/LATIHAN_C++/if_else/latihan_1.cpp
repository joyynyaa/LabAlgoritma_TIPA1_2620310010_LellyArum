#include<iostream>
using namespace std;

int main(){
    int angka;

    cout << "Masukkan angka : " << endl;
    cin >> angka;

    if (angka >=0) {
        cout << " Bilangan positif " << endl;
    }

    else {
        cout << " Bilangan negatif " << endl;
    }

    return 0;
}