#include<iostream>
using namespace std;

int main(){
    int pilihan;

    cout << "=== MENU ===" << endl;
    cout << "1. Nasi goreng" << endl;
    cout << "2. Mie ayam" << endl;
    cout << "3. Ayam geprek" << endl;
    cout << "Pilih menu (1-3): ";
    cin >> pilihan;

    switch (pilihan){
        case 1:
        cout << "Kamu pesan Nasi goreng" << endl;
        break;

        case 2:
        cout << "Kamu pesan Mie ayam" << endl;
        break;

        case 3:
        cout << "Kamu pesan Ayam Geprek" << endl;
        break;
        
        default:
        cout << "Menu tidak tersedia" << endl;
        break;
    }

    return 0;
}