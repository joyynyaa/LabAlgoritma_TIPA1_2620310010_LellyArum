#include<iostream>
#include<string>

using namespace std;

int main(){
    string username;
    string password;

    cout << "Masukkan username : " << endl;
    cin >> username;

    cout << "Masukkan password : " << endl;
    cin >> password;

    if (username == "admin" && password == "111"){
        cout << "kamu berhasil login" << endl;
    }

    else {
        cout << "kamu gagal login" << endl;
    }
    return 0;
}