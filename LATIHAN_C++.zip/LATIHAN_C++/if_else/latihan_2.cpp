#include<iostream>
#include<string>

using namespace std;
int main(){
string pacar;

cout << "Mau ga jadi pacar ku? " << endl;
cin >> pacar;

if (pacar == "mau") {
    cout << "BOELHAHDEHDUE MAKASIHHH SAYANKKK KUHHH " << endl;
}

else { 
    cout << " harus mau ye ajg " << endl;
}
return 0;
}
