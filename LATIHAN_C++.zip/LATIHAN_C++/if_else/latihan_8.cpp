#include<iostream>
using namespace std;

int main(){
    int umur;
    cout << "Masukkan umur: ";
    cin >> umur;

    if (umur >= 17){
        cout << "Kamu sudah boleh buat ktp !" << endl;
    }
    else {
        cout << "Kamu masih bocielss " << endl;
    }
    return 0;
}