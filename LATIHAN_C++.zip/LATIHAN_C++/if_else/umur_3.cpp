#include<iostream>
using namespace std;

int main(){

    int umur;

    cout << "Masukkan umur : " << endl;
    cin >> umur;

    if (umur < 5) {
        cout << " kamu balita " << endl;
    }

    else if (umur >= 5 && umur <=12){
        cout << " kamu anak-anak " << endl;
    }

    else if (umur >= 13 && umur <= 17 ){
        cout << " kamu remaja " << endl;
    }

    else if (umur >= 18 && umur <= 59){
        cout << " kamu dewasa " << endl;
    }
    else {
        cout << " lansia " << endl;
    }

    return 0;
}