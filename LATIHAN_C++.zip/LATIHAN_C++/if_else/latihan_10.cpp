#include<iostream>
using namespace std;

int main (){
    int nilai;
    cout << "Masukkan nilai: " << endl;
    cin >> nilai;

    if (nilai >=85){
        cout << "baik lhoyha" << endl;
    } else if (nilai >=70) {
        cout << "ye mayan lh" << endl;
    }
    else {
        cout << "bljr lg, jan bgo" << endl;
    }

    return 0;
}