#include<iostream>
#include<string>
using namespace std;

int main(){
    string nama;
    string hadiah;
    int nilai1, nilai2, nilai3;
    float rata_rata;

    cout << "Nama Siswa : " << endl;
    cin >> nama;
    cout << "Nilai Pertandingan 1 : " << endl;
    cin >> nilai1;
    cout << "Nilai Pertandingan 2 : " << endl;
    cin >> nilai2;
    cout << "Nilai Pertandingan 3 : " << endl; 
    cin >> nilai3;

    rata_rata = (nilai1 + nilai2 + nilai3) / 3.0;

    if(rata_rata >= 85){
      hadiah = "Komputer Core i5";
    } 

    else if(rata_rata >= 70){
        hadiah = "Uang Rp. 2.500.000";
    }

    else{
      hadiah = "Hiburan";
    }

    cout << "\nLAYAR KELUARAN" << endl;
    cout << "Siswa yang bernama " << nama << endl;
    cout << "Memperoleh nilai rata-rata " << rata_rata << " dari hasil perlombaan yang di ikutinnya. " << endl;
    cout << "Hadiah yang didapat adalah " << hadiah << endl;

    return 0;
}
