#include<iostream>
using namespace std;

int main(){
    int angka;

    cout << "Masukkan angka : " <<endl;
    cin >> angka;

    if (angka == 0){
        cout << "nol" << endl;
    }

    else if (angka > 0 && angka % 2 == 0){
        cout << "positif genap" << endl;
    }

    else if (angka > 0 && angka % 2 != 0){
        cout << "positif ganjil" << endl;
    } 

    else {
        cout << "negatif" << endl;
    }
    return 0;
}