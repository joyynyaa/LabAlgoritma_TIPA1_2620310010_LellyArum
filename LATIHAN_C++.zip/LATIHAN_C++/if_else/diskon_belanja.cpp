#include <iostream>
using namespace std;

int main(){
    float total;
    float diskon = 0;
    float total_bayar;

    cout << "Masukkan total belanja : " << endl;
    cin >> total;

    if (total >= 500000){
        diskon = total * 0.20;
    }
    else if (total >= 250000){
        diskon = total * 0.10;
    }
    else if (total >= 100000){
        diskon = total * 0.05;
    }
    else {
        diskon = 0;
    }

    total_bayar = total - diskon;

    cout << "Total belanja : Rp " << total << endl;
    cout << "Diskon : Rp " << diskon << endl;
    cout << "Total_bayar : Rp " << total_bayar << endl;

    return 0;
}