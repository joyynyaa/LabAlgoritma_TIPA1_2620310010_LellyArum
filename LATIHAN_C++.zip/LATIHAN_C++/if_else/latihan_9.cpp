#include<iostream>
using namespace std;

int main(){
    float nilai;
    cout << "Masukkan nilai ujian: " << endl;
    cin >> nilai;

    if (nilai >=75) {
        cout << "elu lulus " << endl;
    }
    else {
        cout << "g lulus, yahahha " << endl;
    }

    return 0;

}